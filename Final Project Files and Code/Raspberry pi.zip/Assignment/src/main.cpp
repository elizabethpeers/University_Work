#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include <cstdio>
#include <unistd.h>
#include <sys/time.h>
#include <raspicam/raspicam_cv.h>
#include <termios.h>
#include <fcntl.h>
#include <errno.h>
#include <assert.h>
#include <gattlib.h>
#include <gio/gio.h>
#include <glib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <signal.h>
#include<curl/curl.h>
#include <string.h>
#include "math.h"

using namespace cv; //using opencv

// Capture size
#define WIDTH 640
#define HEIGHT 480
int startX=181, startY=0, width=379,height=480;

//initialise trackbar values
int red, green, blue, newImage=0, setup=0, iLowH=0, iHighH=179, iLowS=0, iHighS=255, iLowV=0, iHighV=255, done=0, object_found, confirmed, bad;

int col_iden; //colour identifier to send to CPU. Red=1, Green=2. Blue=3, Other=4

//Initialise image space
Mat display_img, hsv_img, thresh_img, display_img_o, croppedImage;

raspicam::RaspiCam_Cv camera; //initialise camera

//initialise serial
int x_pos, y_pos, x, y;
#define BUF_SIZE 10
int move;
int serial_port;
char buf [BUF_SIZE];
int buf_idx = 0; 
char c;


// UUID for the BLE device's transmit service, e.g. data from peripheral to us
const char *tx_uuid_str = "49535343-1E4D-4BD9-BA61-23C647249616";
uuid_t tx_uuid; // the string above will be converted into the uuid type

//UUID for the BLE device's receive service, e.g. data from us to the peripheral
const char *rx_uuid_str = "49535343-8841-43F4-A8D4-ECBE34729BB3";
uuid_t rx_uuid; // the string above will be converted into the uuid type
// Handle for the BLE connection
gatt_connection_t* m_connection;
GMainLoop *main_loop;


void bluetooth_cb(const uuid_t* uuid, const uint8_t* data, size_t data_length, void* user_data) {
	g_main_loop_quit(main_loop);
}

// function for main interface
void initial(void){
	if (!camera.grab()) { //error for image not acquired
		printf("Failed to acquire image\n");
		usleep(100000);
	}
	namedWindow("Image", CV_WINDOW_AUTOSIZE); //window for image display
	// Add Trackbars
	cvCreateTrackbar("Red", "Image", &red, 1);
	cvCreateTrackbar("Green", "Image", &green, 1);
	cvCreateTrackbar("Blue", "Image", &blue, 1);
	cvCreateTrackbar("Update Image", "Image", &newImage, 1);
	cvCreateTrackbar("Setup", "Image", &setup,1);

	camera.retrieve(display_img_o); // Retreive image
	Mat ROI(display_img_o, Rect(startX,startY,width,height));
	ROI.copyTo(display_img);
	imshow("Image", display_img); //Draw image
	cvtColor(display_img,hsv_img,COLOR_BGR2HSV); //convert from BGR to HSV
	waitKey(100); //allow display update
}

// run for Red, green and blue
void RGB_run(void){
	Mat display_img1=display_img.clone();
	morphologyEx(thresh_img,thresh_img,CV_MOP_OPEN,getStructuringElement(MORPH_RECT,Size(3,3))); //remove noise
	Moments m=moments(thresh_img, true); //find moments of thresholded image
	if (m.m00>10&m.m00<10000){
		x=m.m10/m.m00;
		y=m.m01/m.m00;
		display_img1=display_img.clone();
     	circle(display_img1,Point(x,y),2,Scalar(255,255,255),1,8); //display centre of mass
		destroyWindow("Image"); //Remove old image window and trackbars
		namedWindow("Confirm",CV_WINDOW_AUTOSIZE); //New window for selecting colour
		cvCreateTrackbar("OK", "Confirm", &confirmed, 1);
		cvCreateTrackbar("Retry","Confirm",&bad,1);
		imshow("Confirm",display_img1); //show original image with centre of mass
		waitKey(100);
		while (confirmed==0&bad==0){
			waitKey(100);
		}
		if (confirmed==1){
			confirmed=0;
			destroyWindow("Confirm"); //Remove old image window and trackbars
			waitKey(100);
			x_pos=(x-190)*0.6845; //convert mm
			y_pos=(480-y)*0.6845;
			double hyp=y_pos*y_pos+x_pos*x_pos; //used for distance check
			if (hyp>14400){ //cehck in range
				printf("Outside range\n");
			}else{
			

			sprintf(buf, "%d", x_pos); //send int to buf
	const char *msg = buf;
	const char *msg2 = "d";
	//send buf
	if (0 != gattlib_write_char_by_uuid(m_connection, &rx_uuid, msg, strlen(msg))) {
		fprintf(stderr, "Error: Failed to write to bluetooth interface.\n");
	}
	//send end 
	if (0 != gattlib_write_char_by_uuid(m_connection, &rx_uuid, msg2, strlen(msg2))) {
		fprintf(stderr, "Error: Failed to write to bluetooth interface.\n");
	}
	memset(buf, 0, 10);
	sprintf(buf,"%d", y_pos);
	if (0 != gattlib_write_char_by_uuid(m_connection, &rx_uuid, msg, strlen(msg))) {
		fprintf(stderr, "Error: Failed to write to bluetooth interface.\n");
	}
		if (0 != gattlib_write_char_by_uuid(m_connection, &rx_uuid, msg2, strlen(msg2))) {
		fprintf(stderr, "Error: Failed to write to bluetooth interface.\n");
	}
	memset(buf, 0, 10);
	sprintf(buf,"%d", col_iden);
	if (0 != gattlib_write_char_by_uuid(m_connection, &rx_uuid, msg, strlen(msg))) {
		fprintf(stderr, "Error: Failed to write to bluetooth interface.\n");
	}
			if (0 != gattlib_write_char_by_uuid(m_connection, &rx_uuid, msg2, strlen(msg2))) {
		fprintf(stderr, "Error: Failed to write to bluetooth interface.\n");
	}
	memset(buf, 0, 10);
		// Wait for messages to arrive over bluetooth
	fprintf(stderr, "Waiting for characters to arrive ...\n");
	main_loop = g_main_loop_new(NULL, 0);
	g_main_loop_run(main_loop);
	// Will not return until one of the callbacks calls g_main_loop_quit(main_loop);
	
			}
	}else if (bad==1){
		bad=0;
		destroyWindow("Confirm"); //Remove old image window and trackbars
	}


	}else{
		printf("No object found\n");
	}
	camera.retrieve(display_img_o); // Retreive image
	//crop image
	Mat ROI(display_img_o, Rect(startX,startY,width,height));
	ROI.copyTo(display_img);
	initial();
}


int main(int argc, char *argv[]){
	serial_port = open("14:F9:91:32:E2:52", O_RDWR); // Blocking I/O
					// Parse UUID strings into UUID structures
	if (0 != gattlib_string_to_uuid(tx_uuid_str, strlen(tx_uuid_str), &tx_uuid)) {
		fprintf(stderr, "Could not parse tx_uuid_str\n");
	}

	if (0 != gattlib_string_to_uuid(rx_uuid_str, strlen(rx_uuid_str), &rx_uuid)) {
		fprintf(stderr, "Could not parse rx_uuid_str\n");
	}

	// Open a connection to the device, ensuring a connection is made
	while(m_connection == NULL){

	fprintf(stderr, "Opening a BLE connection\n");
	m_connection = gattlib_connect(NULL, "14:F9:91:32:E2:52", BDADDR_LE_RANDOM, BT_SEC_LOW, 0, 0);
	if (m_connection == NULL) {
		fprintf(stderr, "Error: could not connect to the Bluetooth device\n");
		//return 1;
		int s = sleep(5);
	}
	}
		// Set up a callback for when data arrive on the BT interface
	gattlib_register_notification(m_connection, bluetooth_cb, NULL);
	gattlib_notification_start(m_connection, &tx_uuid);
	
	camera.set(CV_CAP_PROP_FRAME_WIDTH, WIDTH);
	camera.set(CV_CAP_PROP_FRAME_HEIGHT, HEIGHT);
	camera.setVerticalFlip(true);
	camera.setHorizontalFlip(true);
	if (!camera.open()) { //error for camera not opening
		printf("Failed to open camera.\n");
	}
	initial();


	for (;;){
		//Detect trackbar change, run crane, reset bars
			// Register handler to catch Ctrl+C
		if (red==1){ //target red box
			setTrackbarPos("Red", "Image", 0);
			inRange(hsv_img,Scalar(165,50,50),Scalar(179,240, 200),thresh_img); //Threshold image
			col_iden=1;
			RGB_run();
		}else if(green==1){ //target green box
			setTrackbarPos("Green", "Image", 0);
			inRange(hsv_img,Scalar(58,100,30),Scalar(68,250, 150),thresh_img); //Threshold image
			col_iden=2;
			RGB_run();
		}else if(blue==1){ //target blue box
			setTrackbarPos("Blue", "Image", 0);
			inRange(hsv_img,Scalar(100,150,80),Scalar(115,250, 245),thresh_img); //Threshold image
			col_iden=3;
			RGB_run();
		}else if(newImage==1){ //Retreive new image
			setTrackbarPos("Update Image", "Image", 0);
            if (!camera.grab()) { //error for image not acquired
				printf("Failed to acquire image\n");
				usleep(100000);
			}
			camera.retrieve(display_img_o); //Retreive image
			Mat ROI(display_img_o, Rect(startX,startY,width,height));
			Mat croppedImage;
			ROI.copyTo(display_img);
			imshow("Image", display_img); //draw image
			cvtColor(display_img,hsv_img,COLOR_BGR2HSV); //convert from BGR to HSV
		
		}else if(setup==1){ //different colour box
			setup=0; //reset value
			destroyWindow("Image"); //Remove old image window and trackbars
			namedWindow("Select Colour",CV_WINDOW_AUTOSIZE); //New window for selecting colour
			// Create trackbars for colour selection
			cvCreateTrackbar("LowH","Select Colour",&iLowH,179);
			cvCreateTrackbar("HighH","Select Colour",&iHighH,179);
			cvCreateTrackbar("LowS","Select Colour",&iLowS,255);
			cvCreateTrackbar("HighS","Select Colour",&iHighS,255);
			cvCreateTrackbar("LowV","Select Colour",&iLowV,255);
			cvCreateTrackbar("HighV","Select Colour",&iHighV,255);
			cvCreateTrackbar("Run","Select Colour",&done,1);
			Mat display_img1=display_img.clone();
			imshow("Select Colour", display_img1); //Draw image
			namedWindow("Thresholded",CV_WINDOW_AUTOSIZE); //Window for threshoded image
			cvtColor(display_img,hsv_img,COLOR_BGR2HSV); //convert from BGR to HSV
			waitKey(100); //Allow update
			while (done==0){ //while 'done' has not been selected
				inRange(hsv_img,Scalar(iLowH,iLowS,iLowV),Scalar(iHighH,iHighS, iHighV),thresh_img); //Threshold image
				morphologyEx(thresh_img,thresh_img,CV_MOP_OPEN,getStructuringElement(MORPH_RECT,Size(3,3))); //remove noise
				Moments m=moments(thresh_img, true); //find moments of thresholded image
				if (m.m00>10&m.m00<100000){
					object_found=1;
					x=m.m10/m.m00;
					y=m.m01/m.m00;
					display_img1=display_img.clone();
					circle(display_img1,Point(x,y),2,Scalar(255,255,255),1,8); //display centre of mass
					col_iden=4;
				}else{
					object_found=0;
				}
				imshow("Select Colour",display_img1); //show original image with centre of mass
				imshow("Thresholded",thresh_img); //Draw thresholded image
				waitKey(100); //Allow update
			}
			//Once 'done' has been selected
			done=0; // Reset value
			destroyWindow("Select Colour"); //Destroy windows
			destroyWindow("Thresholded");
			waitKey(100);
			if (object_found==1){ // find x & y coordinates of box
				x_pos=(x-190)*0.6845;
				y_pos=y*0.6845;
				if (sqrt(x^2+y^2)>180){
				printf("Outside range\n");
			}else{
					sprintf(buf, "%d", x_pos);
	const char *msg = buf;
	const char *msg2 = "d";
	if (0 != gattlib_write_char_by_uuid(m_connection, &rx_uuid, msg, strlen(msg))) {
		fprintf(stderr, "Error: Failed to write to bluetooth interface.\n");
	}
			if (0 != gattlib_write_char_by_uuid(m_connection, &rx_uuid, msg2, strlen(msg2))) {
		fprintf(stderr, "Error: Failed to write to bluetooth interface.\n");
	}
	memset(buf, 0, 10);
	sprintf(buf,"%d", y_pos);
	if (0 != gattlib_write_char_by_uuid(m_connection, &rx_uuid, msg, strlen(msg))) {
		fprintf(stderr, "Error: Failed to write to bluetooth interface.\n");
	}
			if (0 != gattlib_write_char_by_uuid(m_connection, &rx_uuid, msg2, strlen(msg2))) {
		fprintf(stderr, "Error: Failed to write to bluetooth interface.\n");
	}
	memset(buf, 0, 10);
	sprintf(buf,"%d", col_iden);
	if (0 != gattlib_write_char_by_uuid(m_connection, &rx_uuid, msg, strlen(msg))) {
		fprintf(stderr, "Error: Failed to write to bluetooth interface.\n");
	}
			if (0 != gattlib_write_char_by_uuid(m_connection, &rx_uuid, msg2, strlen(msg2))) {
		fprintf(stderr, "Error: Failed to write to bluetooth interface.\n");
	}
	memset(buf, 0, 10);
		// Wait for messages to arrive over bluetooth
	fprintf(stderr, "Waiting for characters to arrive ...\n");
	main_loop = g_main_loop_new(NULL, 0);
	g_main_loop_run(main_loop);
	// Will not return until one of the callbacks calls g_main_loop_quit(main_loop);
			}

			}else{ //error
				printf("No object found\n");
			}
			//Redraw original window
			initial();
		}
		waitKey(100); // allow to update 
	}
}


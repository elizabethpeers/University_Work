#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include <cstdio>
#include <unistd.h>
#include <sys/time.h>
#include <raspicam/raspicam_cv.h>

using namespace cv;

// Capture size
#define WIDTH 640
#define HEIGHT 480

int startX=181, startY=0, width=379,height=480;

int main(int argc, char *argv[])
{
	// Allocate memory
	Mat display_img, resized;

	raspicam::RaspiCam_Cv camera;
	// Open the camera
	camera.set(CV_CAP_PROP_FRAME_WIDTH, WIDTH);
	camera.set(CV_CAP_PROP_FRAME_HEIGHT, HEIGHT);
	camera.setVerticalFlip(true);
	camera.setHorizontalFlip(true);
	if (!camera.open()) {
		printf("Failed to open camera.\n");
		return 1;
	}

	// Create the "display" window
	namedWindow("Display", WINDOW_AUTOSIZE);

	for (;;) {
		// Acquire an image
		if (!camera.grab()) {
			printf("Failed to acquire image\n");
			usleep(100000);
			continue;
		}

		// Retrieve the image
		camera.retrieve(display_img);
		Mat ROI(display_img, Rect(startX,startY,width,height));
		Mat croppedImage;
		
		ROI.copyTo(resized);
		
		line(resized, Point(190,1), Point(190,480), Scalar( 255, 0, 0 ), 1, 8);
			
		// Draw the final image
		imshow("Display", resized);

		// Update the GUI
		waitKey(1);

		
}
}

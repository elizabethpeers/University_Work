#include <assert.h>
#include <gattlib.h>
#include <gio/gio.h>
#include <glib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <signal.h>
#include<curl/curl.h>
#include <unistd.h>






/// UUID for the BLE device's transmit service, e.g. data from peripheral to us
const char *tx_uuid_str = "49535343-1E4D-4BD9-BA61-23C647249616";
uuid_t tx_uuid; // the string above will be converted into the uuid type

/// UUID for the BLE device's receive service, e.g. data from us to the peripheral
const char *rx_uuid_str = "49535343-8841-43F4-A8D4-ECBE34729BB3";
uuid_t rx_uuid; // the string above will be converted into the uuid type

/// Handle for the BLE connection
gatt_connection_t* m_connection;

/// Main program loop (managed by glib)
GMainLoop *main_loop;

/// Callback routine used when data arrive over bluetooth
void bluetooth_cb(const uuid_t* uuid, const uint8_t* data, size_t data_length, void* user_data) {
	// Parameters:
	// UUID = the UUID of the sender's characteristic
	// data = the received data
	// data_length = number of bytes received
	// user_data = NULL

	// For now, just print the characters to the terminal.
	// TODO - process these characters into a buffer, parse them and upload to Thingspeak.

	int i;
	for(i = 0; i < data_length; i++) {
		printf("%c", data[i]);
	}
	fflush(stdout); // write immediately (don't wait until new line character)
}

/// Callback routine that will be triggered when the program is asked to quit, e.g.
/// by the user pressing Ctrl+C in the terminal.
void int_handler(int signal) {
	fprintf(stderr, "\nQuitting...\n");
	g_main_loop_quit(main_loop);
}

/// Entry point for the program
int main(int argc, char *argv[]) {
	// Parse UUID strings into UUID structures
	if (0 != gattlib_string_to_uuid(tx_uuid_str, strlen(tx_uuid_str), &tx_uuid)) {
		fprintf(stderr, "Could not parse tx_uuid_str\n");
		return 1;
	}

	if (0 != gattlib_string_to_uuid(rx_uuid_str, strlen(rx_uuid_str), &rx_uuid)) {
		fprintf(stderr, "Could not parse rx_uuid_str\n");
		return 1;
	}

	// Check for a device address being passed at the command line
	if (argc != 2) {
		fprintf(stderr, "Usage: %s <device_address>\n", argv[0]);
		fprintf(stderr, "To find device addresses, run:\n    sudo hcitool lescan\n");
		return 1;
	}

	// Open a connection to the device, ensuring a connection is made
	while(m_connection == NULL){

	fprintf(stderr, "Opening a BLE connection to %s ...\n", argv[1]);
	m_connection = gattlib_connect(NULL, argv[1], BDADDR_LE_RANDOM, BT_SEC_LOW, 0, 0);
	if (m_connection == NULL) {
		fprintf(stderr, "Error: could not connect to the Bluetooth device\n");
		//return 1;
		int s = sleep(5);
	}
}

	// Register handler to catch Ctrl+C
	signal(SIGINT, int_handler);

	// Set up a callback for when data arrive on the BT interface
	gattlib_register_notification(m_connection, bluetooth_cb, NULL);
	gattlib_notification_start(m_connection, &tx_uuid);

	// Example of how to send data to the BT device
	const char *msg = "Hello Bluetooth\r\n";
	if (0 != gattlib_write_char_by_uuid(m_connection, &rx_uuid, msg, strlen(msg))) {
		fprintf(stderr, "Error: Failed to write to bluetooth interface.\n");
	}

	// Wait for messages to arrive over bluetooth
	fprintf(stderr, "Waiting for characters to arrive ...\n");
	main_loop = g_main_loop_new(NULL, 0);
	g_main_loop_run(main_loop);
	// Will not return until one of the callbacks calls g_main_loop_quit(main_loop);

	// Once control reaches here, the program is quitting.
	gattlib_disconnect(m_connection);
	return 0;
}
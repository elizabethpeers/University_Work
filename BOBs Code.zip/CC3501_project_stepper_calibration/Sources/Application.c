/*
 * Application.c
 *
 *  Created on: Oct 23, 2018
 *      Author: Lizard
 */

#include "Application.h"
#include "WAIT1.h"
#include "Servo1.h"

void APP_run(void) {
	uint16_t pos;
	for(;;){
		for(pos=0;pos<=255;pos++){
		SERVO1_SetPos(pos); //setpos has 8 bit range (0 to 255)
		WAIT1_Waitms(50);
		}
	}
}



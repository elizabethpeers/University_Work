/*
 * Stepper_movement.h
 *
 *  Created on: 26 Oct 2018
 *      Author: jc300135
 */

#ifndef SOURCES_STEPPER_MOVEMENT_H_
#define SOURCES_STEPPER_MOVEMENT_H_

void stepper3StepDown(char_t a, char_t s, char_t d);
void stepper2StepDown(char_t a, char_t s, char_t d);
void stepper1StepDown(char_t a, char_t s, char_t d);
void stepperArmStepDown(char_t a, char_t s, char_t d);
void stepper3StepUp(char_t a, char_t s, char_t d);
void stepper2StepUp(char_t a, char_t s, char_t d);
void stepper1StepUp(char_t a, char_t s, char_t d);
void stepperArmOffTable(char_t a, char_t s, char_t d);
void stepperArmOrigin(char_t a, char_t s, char_t d);
void stepperArmStepUp(char_t a, char_t s, char_t d);

#endif /* SOURCES_STEPPER_MOVEMENT_H_ */

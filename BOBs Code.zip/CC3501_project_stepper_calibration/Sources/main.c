/* ###################################################################
**     Filename    : main.c
**     Project     : CC3501_project_stepper_calibration
**     Processor   : MK20DX128VLH5
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2018-10-18, 12:55, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.01
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "stepper1Step.h"
#include "BitIoLdd1.h"
#include "stepper2Step.h"
#include "BitIoLdd2.h"
#include "stepper3Step.h"
#include "BitIoLdd3.h"
#include "stepper1Direction.h"
#include "BitIoLdd4.h"
#include "stepper2Direction.h"
#include "BitIoLdd5.h"
#include "stepper3Direction.h"
#include "BitIoLdd6.h"
#include "Term1.h"
#include "Inhr1.h"
#include "ASerialLdd1.h"
#include "SERVO1.h"
#include "Pwm1.h"
#include "PwmLdd1.h"
#include "TU1.h"
#include "WAIT1.h"
#include "MCUC1.h"
#include "AS1.h"
#include "ASerialLdd2.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"


/* User includes (#include below this line is not maintained by Processor Expert) */
//#include "gflib.h"
#include "math.h"
#include "Application.h"
#include "Stepper_movement.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"


/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/

PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

//// Movement of Robob
// Initial setup and variables
Term1_Cls();
char_t a=0; //value of stepper 1 pointer
char_t s=0; //value of stepper 2 pointer
char_t d=0; //value of stepper 3 pointer

uint16_t stepper1MaxLimit = 30; //stepper1 max limit
uint16_t stepper2MaxLimit = 60; //stepper 2 max limit
uint16_t stepper2MidLimit = 40; //stepper 2 mid limit, have to run 2 different for loops to raise the arm the whole way

int OutOfRangeRight = 75; //where to move the picked up boxes if its on the right side of the centre
int OutOfRangeLeft = -75; //where to move the picked up boxes if its on the left side of the centre
////Start up of Robob
/*		Will move to motor positions [1,2,3]=[30,40,0] then =[0,70,0]
 * 		this will get BOB out of the road of the camera to get an image.
 * 		Once an image has been taken and the data points are recieved by BOB
 * 		it will move to [30,30,0].
 */
Term1_SendStr("Press 'u' to enter autonomous mode\r\n"); 		//automatic mode to do image processing
Term1_SendStr("Press 'm' to enter manual mode\r\n"); 			//manual mode to adjust motors seperately. Used for debug and working out where Robob needs to stop

  for (;;){

  char q;
	  if (Term1_KeyPressed()) {
		  Term1_ReadChar(&q);

		if (q=='u'){
Term1_SendStr("\r\nBOB Moving out of camera range\r\n");
for(;;){
	if (a<stepper1MaxLimit){           							// This will move motor 1 and 2 together until 30 steps have been counted
		a++;
		s++;
		stepperArmStepUp(a,s,d);
		WAIT1_Waitms(100);
	}
	else {
		break;
	}
}

for(;;){

	if (s<stepper2MidLimit){ 									// This will move motor 2  until 10 steps have been counted
		s++;
		stepper2StepUp(a,s,d);
		WAIT1_Waitms(100);
	}
	else {
		break;
	}
}

//Autonomous movement (coordinates)
Term1_Cls();

Term1_SendStr("\r\nBOB waits before moving to received data point\r\n");
//WAIT1_Waitms(9000);

/* The following code is for the bluetooth module to receive data from the Pi
 * and then what to do with the data received.
 */

char buf[10];
int index = 0;
byte err;
char c;
int x_done = 0;
char *ptr;

//Wait for data otherwise idle
while (x_done == 0) {
	do{
		err = AS1_RecvChar(&c);
	}
	while (err != ERR_OK);
	if (c == 'd'){
		x_done =1;
		buf[index] = '\0';
		index = 0;
	}
	else{
		buf[index] = c;
		index++;
	}
}
x_done = 0;
int x = strtol(buf,&ptr,10);
memset(buf,0,10);

int y_done = 0;
while (y_done == 0){
	do{
		err=AS1_RecvChar(&c);
	}
	while(err != ERR_OK);
	if (c=='d'){
		buf[index] = '\0';
		index = 0;
		y_done = 1;
	}
	else{
		buf[index] = c;
		index++;
	}
}
int y = strtol(buf,&ptr,10);
memset(buf,0,10);
int c_done = 0;
while (c_done == 0){
	do{
		err = AS1_RecvChar(&c);
	}
	while (err != ERR_OK);
	if (c=='d'){
		buf[index] ='\0';
		index = 0;
		c_done = 1;
	}
		else{
			buf[index] = c;
			index++;
	}
}

int col = strtol(buf, &ptr, 10);
memset(buf,0,10);


////Once Coordinates are received from Pi

//WAIT1_Waitms(1000);


Term1_SendStr("\r\nBOB moving to pick up box\r\n");

Term1_SendStr("X Coordinate:\r\n");
Term1_SendNum(x);
Term1_SendStr("\r\nY Coordinate:\r\n");
Term1_SendNum(y);

float angle = atan2f(x,y+100); 									//Function to calculate the angle the rotate BOB (in radians)
int asteps = angle/0.03141594;									//Converts angle to steps
float dis = hypotf(x,y);										//Function to calculate how far to extend BOBs arm (in mm)
int ArmSteps = dis/6;											// Convert distance to steps

Term1_SendStr("\r\nAngle (Radians)\r\n");
Term1_SendFloatNum(angle);
Term1_SendStr("\r\nSteps (1 step is 1.8 degree)\r\n");
Term1_SendNum(asteps);
Term1_SendStr("\r\n Hypotenuse (sqrt(x^2 + y^2))\r\n");
Term1_SendFloatNum(dis);
Term1_SendStr("\r\n Number of steps to extend arm (1 step = 6 mm) \r\n");
Term1_SendNum(ArmSteps);
Term1_SendStr("\r\n");
WAIT1_Waitms(1000);

for (;;){

	if (asteps<0){												//if the angle is negative rotate BOB to the left
		asteps++;
		d=d-1;
		stepper3StepDown(a,s,d); //left
		WAIT1_Waitms(100);
	}
	else if (asteps>0){											//if the angle is positive rotate BOB to the right
		asteps = asteps-1;
		d++;
		stepper3StepUp(a,s,d);//right
		WAIT1_Waitms(100);
	}
	else{
		break;
	}
}
for (;;){
	if (ArmSteps>0){											// Since the ratio between stepper motor 1 and 2 is 1:1, the steps
			ArmSteps = ArmSteps-1;								// are reduced until the number of steps calculated (ArmSteps) equals 0
			a=a-1;												//This extends the arm to the required spot
			s=s-1;
			stepperArmStepDown(a,s,d);
			WAIT1_Waitms(100);
		}
	else {
		break;
	}
}
int j=0;														//This places the arm back down on the table as it will be slightly up
for (;;){
	if (j<6){
			j++;
			a=a-1;
			stepper1StepUp(a,s,d);
			WAIT1_Waitms(100);
		}
	else {
		break;
	}
}

WAIT1_Waitms(1000);

//servo pick up object
	SERVO1_SetPos(140); // 8 bit number to be calibrated positional servo

//}
Term1_SendStr("\r\nMove arm up 12 steps\r\n");
WAIT1_Waitms(1000);														//This moves the arm up so it can rotate freely to the side
int t=0;
for(;;){
	if (t<12){

		a++;
		t++;
		stepper1StepDown(a,s,d);
		WAIT1_Waitms(100);
	}
	else{
		break;
	}
}
WAIT1_Waitms(1000);
for (;;){
	if (d<OutOfRangeRight && d>0 ){								//If the box picked up is on the right side it will rotate to the right to then put the box down
			d++;
			stepper3StepUp(a,s,d);
			WAIT1_Waitms(100);
		}
	else if (d>OutOfRangeLeft && d<0 ){							//If the box picked up is on the left side it will rotate to the left to then put the box down
				d=d-1;
				stepper3StepDown(a,s,d);
				WAIT1_Waitms(100);
			}
	else {
		break;
	}
}

//servo drops object
	SERVO1_SetPos(240); // 8 bit number to be calibrated positional servo

//Move base back to Origin [0] which is a fully extended arm
WAIT1_Waitms(1000);
for (;;){
	if (d > 0){
			d=d-1;
			stepper3StepDown(a,s,d);
			WAIT1_Waitms(100);
		}
	else if (d < 0){
				d++;
				stepper3StepUp(a,s,d);
				WAIT1_Waitms(100);
			}
	else {
		break;
	}
}
for(;;){
	if (s>0){
		a=a-1;
		s=s-1;
		stepperArmStepDown(a,s,d);
		WAIT1_Waitms(100);
	}
	else if (s == 0 && a>0){
		a=a-1;
		stepper1StepUp(a,s,d);
		WAIT1_Waitms(100);
	}
	else if (a == 0 && s==0){
			Term1_SendStr("\r\nNo steps available\r\n");
			WAIT1_Waitms(100);
			break;
	}
	else {
		break;
	}
}
AS1_SendChar("d"); // Send signal back to Pi to let it know you can select another box is you reselect autonomous mode
Term1_SendStr("Press 'u' to enter autonomous mode\r\n");
Term1_SendStr("Press 'm' to enter manual mode\r\n");
		}



//Manual movement (key press')
if (q=='m'){
Term1_Cls();
Term1_SendStr("Robob Stepper Motor Manual\r\n\r\n");
Term1_SendStr("Press 'a' to move stepper 1 and 2 to mid limit on ground (max(a,s) = [30,40]) \r\n");
Term1_SendStr("Press 'z' to move stepper 1 and 2 to min limit (min(a,s) = [0,0]) \r\n");
Term1_SendStr("Press 's' to move stepper 1 and 2 to max limit off ground (max(a,s) = [0,70]) \r\n");
Term1_SendStr("Press 'd' to move stepper 3 to the right\r\n");
Term1_SendStr("Press 'v' to move stepper 3 to the left\r\n");
  for (;;){

  char b;
	  if (Term1_KeyPressed()) {
		  Term1_ReadChar(&b);

			switch (b) {
				case 'a':
					if (a<stepper1MaxLimit){
						a++;
						s++;
						stepperArmStepUp(a,s,d);
						break;
					}
					if (s<stepper2MidLimit){
								s++;
								stepper2StepUp(a,s,d);
						break;
					}
					else {
						break;
					}
				case 't':
					a=a-1;
					stepper1StepUp(a,s,d);
					break;
				case 'w':
					s++;
					stepper2StepDown(a,s,d);
					break;
				case 'r':
					a++;
					stepper1StepDown(a,s,d);
					break;
				case 'e':
					s=s-1;
					stepper2StepUp(a,s,d);
					break;
				case 's':
					if (s<stepper2MaxLimit){
						s++;
						a=a-1;
						stepperArmOffTable(a,s,d);
						break;
					}
					else {
						break;
					}
				case 'd':
					d++;
					stepper3StepUp(a,s,d);
					break;
				case 'z':
					if (s>30){
						s=s-1;
						stepper2StepDown(a,s,d);
						break;
					}
					if (a>0){
						s=s-1;
						a=a-1;
						stepperArmStepDown(a,s,d);
						break;
					}
					if (a == 0 && s==0){
						Term1_SendStr("\r\nNo steps available\r\n");
						break;
					}
				case 'v':

					d=d-1;
					stepper3StepDown(a,s,d);

					break;

			}
	  }
	}
}

	  }
  }


//	 INFINITE LOOP STEPPERS
//  for (int i=0; i<50; ++i){
//		  	 // stepper 1 infinite spin
//		  	stepper1Direction_PutVal(1);
//		  	stepper1Step_PutVal(1);
//		  	for (int i=0; i<5000; i++);
//		  	stepper1Step_PutVal(0);
//		  	for (int i=0; i<5000; i++);
//
////		  	// stepper 2 infinite spin
//		  	stepper2Direction_PutVal(1);
//		  	stepper2Step_PutVal(1);
//		  	for (int i=0; i<5000; i++);
//		  	stepper2Step_PutVal(0);
//		  	for (int i=0; i<5000; i++);
////
//		  	// stepper 3 infinite spin
//		  	stepper3Direction_PutVal(1);
//		  	stepper3Step_PutVal(1);
//		  	for (int i=0; i<5000; i++);
//		  	stepper3Step_PutVal(0);
//		  	for (int i=0; i<5000; i++);
////
//}





  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/

}/*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.5 [05.21]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/

/*
 * Application.h
 *
 *  Created on: Oct 23, 2018
 *      Author: Lizard
 */

#ifndef SOURCES_APPLICATION_H_
#define SOURCES_APPLICATION_H_

void APP_run(void);

#endif /* SOURCES_APPLICATION_H_ */

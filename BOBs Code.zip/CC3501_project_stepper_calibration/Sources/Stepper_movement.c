/*
 * Stepper_movement.c
 *
 *  Created on: 26 Oct 2018
 *      Author: jc300135
 */
#include "stepper1Step.h"
#include "stepper2Step.h"
#include "stepper3Step.h"
#include "stepper1Direction.h"
#include "stepper2Direction.h"
#include "stepper3Direction.h"
#include "Term1.h"

#include "SERVO1.h"
#include "PWM1.h"
#include "PwmLdd1.h"

#include "WAIT1.h"



	void stepperArmStepUp(char_t a, char_t s, char_t d)
	{
		stepper1Direction_PutVal(1);
		stepper1Step_PutVal(1);
		for (int i=0; i<5000; i++);
		stepper1Step_PutVal(0);
		for (int i=0; i<5000; i++);

		stepper2Direction_PutVal(1);
		stepper2Step_PutVal(1);
		for (int i=0;i<5000; i++){}
		stepper2Step_PutVal(0);
		for (int i=0; i<5000; i++){}

		Term1_SendStr("\tstepper 1 position=");
		Term1_SendNum(a);
		Term1_SendStr("\tstepper 2 position=");
		Term1_SendNum(s);
		Term1_SendStr("\tstepper 3 position=");
		Term1_SendNum(d);
		Term1_SendStr("\r\n");

	}
	void stepperArmOrigin(char_t a, char_t s, char_t d){
			stepper1Direction_PutVal(1);
			stepper1Step_PutVal(1);
			for (int i=0; i<5000; i++);
			stepper1Step_PutVal(0);
			for (int i=0; i<5000; i++);
			stepper2Direction_PutVal(0);
			stepper2Step_PutVal(1);
			for (int i=0; i<5000; i++);
			stepper2Step_PutVal(0);
			for (int i=0; i<5000; i++);

			Term1_SendStr("\tstepper 1 position=");
			Term1_SendNum(a);
			Term1_SendStr("\tstepper 2 position=");
			Term1_SendNum(s);
			Term1_SendStr("\tstepper 3 position=");
			Term1_SendNum(d);
			Term1_SendStr("\r\n");
	}
	void stepperArmOffTable(char_t a, char_t s, char_t d)
	{
		stepper1Direction_PutVal(0);
		stepper1Step_PutVal(1);
		for (int i=0; i<5000; i++);
		stepper1Step_PutVal(0);
		for (int i=0; i<5000; i++);

		stepper2Direction_PutVal(1);
		stepper2Step_PutVal(1);
		for (int i=0; i<5000; i++);
		stepper2Step_PutVal(0);
		for (int i=0; i<5000; i++);

		Term1_SendStr("\tstepper 1 position=");
		Term1_SendNum(a);
		Term1_SendStr("\tstepper 2 position=");
		Term1_SendNum(s);
		Term1_SendStr("\tstepper 3 position=");
		Term1_SendNum(d);
		Term1_SendStr("\r\n");

	}

	void stepper1StepUp(char_t a, char_t s, char_t d)
	{
		stepper1Direction_PutVal(1);
		stepper1Step_PutVal(1);
		for (int i=0; i<5000; i++);
		stepper1Step_PutVal(0);
		for (int i=0; i<5000; i++);


		Term1_SendStr("\tstepper 1 position=");
		Term1_SendNum(a);
		Term1_SendStr("\tstepper 2 position=");
		Term1_SendNum(s);
		Term1_SendStr("\tstepper 3 position=");
		Term1_SendNum(d);
		Term1_SendStr("\r\n");

	}
	void stepper2StepUp(char_t a, char_t s, char_t d)
	{
		stepper2Direction_PutVal(1);
		stepper2Step_PutVal(1);
		for (int i=0;i<5000; i++){}
		stepper2Step_PutVal(0);
		for (int i=0; i<5000; i++){}

		Term1_SendStr("\tstepper 1 position=");
		Term1_SendNum(a);
		Term1_SendStr("\tstepper 2 position=");
		Term1_SendNum(s);
		Term1_SendStr("\tstepper 3 position=");
		Term1_SendNum(d);
		Term1_SendStr("\r\n");

	}
	void stepper3StepUp(char_t a, char_t s, char_t d)
	{
		stepper3Direction_PutVal(1);
		stepper3Step_PutVal(1);
		for (int i=0; i<5000; i++);
		stepper3Step_PutVal(0);
		for (int i=0; i<5000; i++);

		Term1_SendStr("\tstepper 1 position=");
		Term1_SendNum(a);
		Term1_SendStr("\tstepper 2 position=");
		Term1_SendNum(s);
		Term1_SendStr("\tstepper 3 position=");
		Term1_SendNum(d);
		Term1_SendStr("\r\n");

	}

	void stepperArmStepDown(char_t a, char_t s, char_t d)
	{
		stepper1Direction_PutVal(0);
		stepper1Step_PutVal(1);
		for (int i=0; i<5000; i++);
		stepper1Step_PutVal(0);
		for (int i=0; i<5000; i++);

		stepper2Direction_PutVal(0);
		stepper2Step_PutVal(1);
		for (int i=0;i<5000; i++){}
		stepper2Step_PutVal(0);
		for (int i=0; i<5000; i++){}


		Term1_SendStr("\tstepper 1 position=");
		Term1_SendNum(a);
		Term1_SendStr("\tstepper 2 position=");
		Term1_SendNum(s);
		Term1_SendStr("\tstepper 3 position=");
		Term1_SendNum(d);
		Term1_SendStr("\r\n");
	}
	void stepper1StepDown(char_t a, char_t s, char_t d)
	{
		stepper1Direction_PutVal(0);
		stepper1Step_PutVal(1);
		for (int i=0; i<5000; i++);
		stepper1Step_PutVal(0);
		for (int i=0; i<5000; i++);

		Term1_SendStr("\tstepper 1 position=");
		Term1_SendNum(a);
		Term1_SendStr("\tstepper 2 position=");
		Term1_SendNum(s);
		Term1_SendStr("\tstepper 3 position=");
		Term1_SendNum(d);
		Term1_SendStr("\r\n");

	}
	void stepper2StepDown(char_t a, char_t s, char_t d)
	{
		stepper2Direction_PutVal(0);
		stepper2Step_PutVal(1);
		for (int i=0;i<5000; i++){}
		stepper2Step_PutVal(0);
		for (int i=0; i<5000; i++){}

		Term1_SendStr("\tstepper 1 position=");
		Term1_SendNum(a);
		Term1_SendStr("\tstepper 2 position=");
		Term1_SendNum(s);
		Term1_SendStr("\tstepper 3 position=");
		Term1_SendNum(d);
		Term1_SendStr("\r\n");

	}
	void stepper3StepDown(char_t a, char_t s, char_t d)
	{
		stepper3Direction_PutVal(0);
		stepper3Step_PutVal(1);
		for (int i=0; i<5000; i++);
		stepper3Step_PutVal(0);
		for (int i=0; i<5000; i++);

		Term1_SendStr("\tstepper 1 position=");
		Term1_SendNum(a);
		Term1_SendStr("\tstepper 2 position=");
		Term1_SendNum(s);
		Term1_SendStr("\tstepper 3 position=");
		Term1_SendNum(d);
		Term1_SendStr("\r\n");

	}


